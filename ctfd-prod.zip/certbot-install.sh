#!/bin/bash

# Ask for user input for domain and email
read -p "Enter your domain name: " DOMAIN
read -p "Enter your email address for Let's Encrypt: " EMAIL

# Prepare temporary Nginx configuration for Let's Encrypt challenge
echo "Creating temporary Nginx configuration for Let's Encrypt validation..."

cat <<EOL > ./nginx/default.conf
server {
    listen 80;
    server_name $DOMAIN;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 200 "Temporary HTTP server for Let's Encrypt validation\n";
    }
}
EOL

# Restart containers to apply the temporary configuration
echo "Restarting Docker containers with temporary Nginx configuration..."

docker compose down
docker compose up -d nginx

# Request SSL certificate from Let's Encrypt using Certbot
echo "Requesting SSL certificate from Let's Encrypt..."

docker run --rm \
  -v "$(pwd)/certbot:/etc/letsencrypt" \
  -v "$(pwd)/certbot/www:/var/www/certbot" \
  certbot/certbot certonly \
  --webroot --webroot-path=/var/www/certbot \
  --email $EMAIL \
  --agree-tos \
  --no-eff-email \
  -d $DOMAIN

# Check if certbot was successful
if [ $? -ne 0 ]; then
    echo "Certbot failed to obtain the SSL certificate. Please check the logs for more details."
    exit 1
fi

# Revert Nginx configuration to HTTPS
echo "Reverting Nginx configuration to HTTPS..."

cat <<EOL > ./nginx/default.conf
server {
    listen 80;
    server_name $DOMAIN;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name $DOMAIN;

    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;

    location / {
        proxy_pass http://ctfd:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOL

# Final message
echo "SSL certificate has been successfully obtained and HTTPS is now configured for $DOMAIN."

