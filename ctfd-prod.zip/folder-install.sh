#!/bin/bash

# Get the current user
USER=$(whoami)

# Define the directory paths
LOG_DIR="./ctfd-data/logs"
MYSQL_DIR="./mysql-data"

# Check if the ctfd-data directory exists
if [ ! -d "./ctfd-data" ]; then
    echo "ctfd-data directory does not exist. Creating it now..."
    sudo mkdir ./ctfd-data
else
    echo "ctfd-data directory already exists."
fi

# Check if the logs directory exists
if [ ! -d "$LOG_DIR" ]; then
    echo "Logs directory does not exist. Creating it now..."
    sudo mkdir -p $LOG_DIR
else
    echo "Logs directory already exists."
fi

# Check if the mysql-data directory exists
if [ ! -d "$MYSQL_DIR" ]; then
    echo "MySQL data directory does not exist. Creating it now..."
    sudo mkdir -p $MYSQL_DIR
else
    echo "MySQL data directory already exists."
fi

# Change the ownership of the ctfd-data and mysql-data directories to the current user (ctf)
echo "Changing ownership of the directories to user $USER..."
sudo chown -R $USER:$USER ./ctfd-data ./mysql-data

# Set the correct permissions to ensure the user can read/write
echo "Setting correct permissions for the directories..."
sudo chmod -R 755 ./ctfd-data ./mysql-data

echo "Directories setup complete. Ownership and permissions are now correct."

