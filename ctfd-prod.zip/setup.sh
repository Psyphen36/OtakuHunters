#!/bin/bash

# Ask for the domain name
read -p "Enter your domain name (e.g., example-domain.com): " DOMAIN_NAME

# Replace all occurrences of 'example-domain.com' with the specified domain in all necessary files
echo "Updating configuration files with domain: $DOMAIN_NAME"

# Update nginx default.conf
sed -i "s/example-domain.com/$DOMAIN_NAME/g" ./nginx/default.conf

# Update .env file
sed -i "s/example-domain.com/$DOMAIN_NAME/g" ./.env

# Update docker-compose.yml file
sed -i "s/example-domain.com/$DOMAIN_NAME/g" ./docker-compose.yml

# Ask for database details
echo "Now, let's set up your database credentials."

read -p "Enter your database username (default: ctfd_user): " DB_USER
DB_USER=${DB_USER:-ctfd_user}

# Password without echo
echo -n "Enter your database password (default: ctfd_pass): "
stty -echo
read DB_PASS
stty echo
echo
DB_PASS=${DB_PASS:-ctfd_pass}

read -p "Enter your database name (default: ctfd_database): " DB_NAME
DB_NAME=${DB_NAME:-ctfd_database}

# Ask for the MySQL root password
echo -n "Enter the MySQL root password (default: rootpass): "
stty -echo
read MYSQL_ROOT_PASS
stty echo
echo
MYSQL_ROOT_PASS=${MYSQL_ROOT_PASS:-rootpass}

# Replace database details in docker-compose.yml
sed -i "s/ctfd_user/$DB_USER/g" ./docker-compose.yml
sed -i "s/ctfd_pass/$DB_PASS/g" ./docker-compose.yml
sed -i "s/ctfd_database/$DB_NAME/g" ./docker-compose.yml
sed -i "s/rootpass/$MYSQL_ROOT_PASS/g" ./docker-compose.yml

# Replace database details in .env using | as the delimiter instead of / to avoid issues with the URL
sed -i "s|mysql+pymysql://ctfd_user:ctfd_pass@db/ctfd_database|mysql+pymysql://$DB_USER:$DB_PASS@db/$DB_NAME|g" ./.env

# Update MYSQL_DATABASE in .env to be consistent
sed -i "s/ctfd_database/$DB_NAME/g" ./.env

# Ask for SECRET_KEY
echo "Now, let's set up a secure random string for SECRET_KEY."

read -p "Enter your SECRET_KEY (default: change_me_to_a_secure_random_string): " SECRET_KEY
SECRET_KEY=${SECRET_KEY:-change_me_to_a_secure_random_string}

# Replace SECRET_KEY in .env file
sed -i "s/SECRET_KEY=change_me_to_a_secure_random_string/SECRET_KEY=$SECRET_KEY/g" ./.env

echo "Configuration files updated."

# Run the required scripts
echo "Running folder setup..."
sh folder-install.sh

echo "Running certbot setup..."
sh certbot-install.sh

echo "Starting the Docker containers..."
docker compose up -d

echo "Setup complete! The application is now running at https://$DOMAIN_NAME"

